# Core of stats
This folder contains pure jnp.array statistics logic.